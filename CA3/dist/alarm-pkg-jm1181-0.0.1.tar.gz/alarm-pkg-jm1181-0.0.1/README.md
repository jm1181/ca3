This is a program that allows you to get the latest information
regarding COVID-19, the news and the latest weather. It also allows you
to create alarms that read out the news, weather or COVID updates 
if that is what you would like to do.

To run, you download the ca3.py file and simply find the
directory it is in and type 'python3 ca3.py' into your terminal. 
Then click the html link that comes up and you can create your 
own alarms and find out the latest news, weather and coronavirus updates.
For this to work, python must be installed on your device.

The page will display the notifications on the right hand side
and the alarms you have set on the left hand side. To set an alarm you
enter the time and date you would like this alarm to be set, add a label to it
and check the boxes whether you would like the news, weather or coronavirus
updates to be read out to you when the alarm is set for.